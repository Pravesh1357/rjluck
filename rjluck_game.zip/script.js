
let multiplier = 1.00;
let interval;
const multiplierDisplay = document.getElementById("multiplier");
const startBtn = document.getElementById("startBtn");
const cashoutBtn = document.getElementById("cashoutBtn");

startBtn.onclick = () => {
    multiplier = 1.00;
    multiplierDisplay.innerText = multiplier.toFixed(2) + "x";
    cashoutBtn.disabled = false;
    interval = setInterval(() => {
        multiplier += 0.01;
        multiplierDisplay.innerText = multiplier.toFixed(2) + "x";
        if (Math.random() < 0.01) {
            clearInterval(interval);
            alert("Game crashed at " + multiplier.toFixed(2) + "x");
            cashoutBtn.disabled = true;
        }
    }, 100);
};

cashoutBtn.onclick = () => {
    clearInterval(interval);
    alert("You cashed out at " + multiplier.toFixed(2) + "x");
    cashoutBtn.disabled = true;
};
